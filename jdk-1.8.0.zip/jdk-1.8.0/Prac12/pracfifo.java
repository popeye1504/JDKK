import java.util.*;

public class pracfifo
{
   public static void main(String[] args)
   {
      int f,p,pages,search,num=0;
      int pageHit=0,pageFault=0;
      
      boolean flag=true;
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter the number of frames");
      f=sc.nextInt();
      System.out.println("Enter the length of reference string");
      p=sc.nextInt();
      int frame[]=new int[f];
      int page[]=new int[p];
      
      for(int i=0;i<f;i++)
      {
         frame[i]=-1;
      }
      System.out.println("Enter the reference string");
      for(int i=0;i<p;i++)
      {
          page[i]=sc.nextInt();
      }
      
      for(int i=0;i<p;i++)
      {
         flag=true;
         pages=page[i];
         
         for(int j=0;j<f;j++)
         {
            if(frame[j]==pages)
            {
             
               pageHit++;
               flag=false;
               break;
            }
         }
         if(flag==true)
         {
            pageFault++;
         }
         if(num==f)
         {
            num=0;
         }
         if(flag)
         {
         frame[num]=pages;
         num++;
         }
        for(int k=0;k<f;k++)
      {
         System.out.print(frame[k]+"\t");
      }
      System.out.println(); 
     }
      System.out.println("No. of page hit: "+pageHit);
       System.out.println("No. of page fault: "+pageFault);
       double hitratio;
       hitratio=(double)pageHit/p;
       System.out.println("The Hit Ratio is :"+hitratio);
      
   }
}

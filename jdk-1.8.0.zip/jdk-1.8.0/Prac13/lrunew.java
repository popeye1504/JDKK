import java.util.*;

public class lrunew
{
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		ArrayList<Integer> st=new ArrayList<Integer>();
		int frame,reflen,pointer=0,hit=0,search,temp,fault=0;
		boolean isFull=false;
		System.out.println("Enter no. frames:");
		frame=sc.nextInt();
		System.out.println("Enter length of reference string:");
		reflen=sc.nextInt();
		int[] buff=new int[frame];
		int[] ref=new int[reflen];
		int[][] lay=new int[frame][reflen];

		System.out.println("Enter Reference String:");
		for (int i=0; i<reflen;i++ )
		{
			ref[i]=sc.nextInt();	
		}
		for(int i=0;i<frame;i++)
		{
			buff[i]=-1;
		}

		for(int i=0;i<reflen;i++)
		{
			if(st.contains(ref[i]))
			{
				st.remove(st.indexOf(ref[i]));
			}
			st.add(ref[i]);
			search=-1;
			for(int j=0;j<frame;j++)
			{
				if(buff[j]==ref[i])
				{
					search=j;
					hit++;
					break;
				}
			}
			if(search==-1)
			{
				if(isFull)
				{
					int min=reflen;
					for(int j=0;j<frame;j++)
					{
						temp=st.indexOf(buff[j]);
						{
							if(temp<min)
							{
								min=temp;
								pointer=j;
							}
						}
					}
				}
				buff[pointer]=ref[i];
				pointer++;
				fault++;
				if(pointer==frame)
				{
					isFull=true;
					pointer=0;
				}
			}
			for(int j=0;j<frame;j++)
			{
				lay[j][i]=buff[j];

			}
		}
		for (int i=0;i<frame ;i++ ) {
			for (int j=0;j<reflen ;j++ ) {

				System.out.print(lay[i][j]+"\t");
			}
			System.out.println();
			
		}

	}
}
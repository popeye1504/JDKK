import java.util.*;

public class bank{
	public static void main(String[] args) {
		
		int r,p;
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter no. of resources:");
		r=s.nextInt();
		System.out.print("Enter no .of processes:");
		p=sc.nextInt();
		int[][] max=new int[p][r];
		int[][] all=new int[p][r];
		int[][] need=new int[p][r];
		int[] ava=new int[r];
		int[] safe=new int[p];
		int[] maxr[]=new int[r];
		System.out.print("Enter MAX resources:");
		
		for(int i=0;i<r;i++)
		{
					ava[i]=sc.nextInt();
		}
		System.out.print("Enter Allocation Matrix:");
		for(int i=0;i<p;i++)
		{
			for (int j=0;j<r;j++ )
			{
					all[i][j]=sc.nextInt();
					ava[j]=ava[j]-all[i][j];
			}
		}

		System.out.print("Enter Maximum Matrix:");
		
		for(int i=0;i<p;i++)
		{
			for (int j=0;j<r;j++ )
			{
					max[i][j]=sc.nextInt();
			}
		}
		System.out.println("Need Matrix:");
		for(int i=0;i<p;i++)
		{
			for (int j=0;j<r;j++ )
			{
					need[i][j]=max[i][j]-all[i][j];
					System.out.print("\t"+need[i][j]);

			}System.out.println();
		}
		for(int i=0;i<p;i++)
		{
			finish[i]=false;
		}

		while(count<n)
		{
			found=false;
			for(int i=0;i<p;i++)
			{
				if(finish[i]=false)
				{
					for(int j=0;j<r;j++)
					{
						if(need[i][j]>ava[i][j])
						{
							break;
						}
					}
				}
				if(j==m)
				{

				}
			}
		}


		
	}
}
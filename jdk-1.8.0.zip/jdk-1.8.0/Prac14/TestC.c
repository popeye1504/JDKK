#include <jni.h>
#include "TestC.h"
#include <stdio.h>
#include <math.h>

JNIEXPORT jint JNICALL Java_TestC_add(JNIEnv *env,jobject object,jint n1,jint n2)
{
   jint res;
   res=n1+n2;
   return res;
}
JNIEXPORT jint JNICALL Java_TestC_sub(JNIEnv *env,jobject object,jint n1,jint n2)
{
   jint res;
   res=n1-n2;
   return res;
}
JNIEXPORT jint JNICALL Java_TestC_mul(JNIEnv *env,jobject object,jint n1,jint n2)
{
   jint res;
   res=n1*n2;
   return res;
}
JNIEXPORT jfloat JNICALL Java_TestC_div(JNIEnv *env,jobject object,jint n1,jint n2)
{
   jfloat res;
   res=n1/n2;
   return res;
}


//javah -jni TestC
//javac TestC.java
//locate jni.h    copy till include last option
//locate jni_md.h copy till linux
//gcc -I/paste_1st_cmd -I/paste_2nd_cmd -o libTestC.so -shared -fPIC TestC.c
//java -Djava.library.path=. TestC
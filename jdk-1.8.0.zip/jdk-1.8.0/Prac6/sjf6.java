import java.util.*;

public class sjf6{

void es(){

	Scanner sc=new Scanner(System.in);
	int count=0,time=0,at,bt;
	int min=100,shortest=0,sum;
	boolean check=false;
	System.out.println("Enter no. of processes:");
	int num=sc.nextInt();
	process[] pr=new process[num];
	for(int i=0;i<num;i++)
		{
			System.out.println("Enter AT & BT:");
			at=sc.nextInt();
			bt=sc.nextInt();
			pr[i]=new process("P"+(i+1),at,bt);
		}

	while(count<num)
	{
		for(int i=0;i<num;i++)
		{
			if(pr[i].AT<=time && (pr[i].remBT<min && pr[i].remBT>0))
			{
				shortest=i;
				min=pr[i].remBT;
				check=true;
			}
		}
		if(check=false)
		{
			time++;
			continue;
		}
		pr[shortest].remBT--;
		min=pr[shortest].remBT;
		if(min==0)
		{
			min=100;
			sum=time+1;
			pr[shortest].CT=sum;
			pr[shortest].TAT=pr[shortest].CT-pr[shortest].AT;
			pr[shortest].WT=pr[shortest].TAT-pr[shortest].BT;
			count++;
			pr[shortest].display();
		}
		time++;
	}

}
public static void main(String[] args) {
		sjf6 s1=new sjf6();
		s1.es();
	}


}
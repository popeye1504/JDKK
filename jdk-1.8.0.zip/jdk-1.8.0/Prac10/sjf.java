import java.util.*;

public class sjf
{
   private Scanner sc;
   public void execute()
   {
      int min=Integer.MAX_VALUE;
      double avgTaT=0,avgWT=0;
      int count=0,sum=0,time=0,shortest=0;
      sc=new Scanner(System.in);
      boolean check=false;
      
      System.out.println("Enter the number of processes ");
      int numprocess=sc.nextInt();
      Process1 process[]=new Process1[numprocess];
      for(int i=0;i<numprocess;i++)
      {
         System.out.println("P("+(i+1)+"):Enter the arrival time and burst time");
         int at=sc.nextInt();
         int bt=sc.nextInt();
         process[i]=new Process1("P("+(i+1)+")",bt,at); 
      }
      
      System.out.println("name\tBT\tAT\tCT\tTAT\tWT");
      System.out.println("===================================================================");
      
      while(count<numprocess)
      {
          for(int i=0;i<numprocess;i++)
          {
             if(process[i].AT<=time &&(process[i].remBT<min && process[i].remBT>0))
             {
               shortest=i;
               min=process[i].remBT;
               check=true;   
             }
          }
          if(check==false)
          {
              time++;
              continue;
          }
          
          process[shortest].remBT--;
          min=process[shortest].remBT;
          if(min==0)
          {
              min=Integer.MAX_VALUE;
              sum=time+1;
              process[shortest].CT=sum;
              process[shortest].TAT=process[shortest].CT-process[shortest].AT;
              process[shortest].WT=process[shortest].TAT-process[shortest].BT;
              avgTaT=avgTaT+process[shortest].TAT;
              avgWT=avgWT+process[shortest].WT;
              process[shortest].display();
              count++;
          }
          time++;
      }
                
   }
   public static void main(String[] args)
   {
      sjf s1=new sjf();
      s1.execute();
   }
}
